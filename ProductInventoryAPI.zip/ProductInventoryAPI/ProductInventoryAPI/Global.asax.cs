﻿using ProductInventoryAPI.Handler;
using System.Web.Http;
using System.Web.Mvc;

namespace ProductInventoryAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            new ProductLogRequestResponseHandler();   //  To start executing job async when application start
        }
    }
}
