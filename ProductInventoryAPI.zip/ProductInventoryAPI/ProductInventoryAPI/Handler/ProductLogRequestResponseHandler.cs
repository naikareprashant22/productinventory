﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using ProductInventoryAPI.Models;
using System.Net;
using ProductInventoryAPI.Constants;
using ProductInventoryAPI.DAL;

namespace ProductInventoryAPI.Handler
{
    public class ProductLogRequestResponseHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request, CancellationToken cancellationToken)
        {
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);
            await Task.Delay(delayFeedRequest);
            String url = request.RequestUri.ToString();
            string UniqueID = string.Empty;
            string MethodType = request.Method.ToString();
            Uri webUri = new Uri(url);
            url = webUri.AbsolutePath;

            string[] arr = url.Split('/');
            if(arr.Length >= 4)
            {
                UniqueID = arr[3].ToString();
            }
            
            //UniqueID = HttpUtility.ParseQueryString(webUri.Query).Get("id");
            if ((MethodType == "PUT" || MethodType == "DELETE") && UniqueID == "")
            {
                throw new HttpException(404, "Not Found");
            }
                   
            var authHeader = request.Headers.Authorization;
            int errorCode = 200;

            if (authHeader != null)
            {
                try
                {
                    var authenticationToken = request.Headers.Authorization.Parameter;
                  
                    var decodedAuthenticationToken = Encoding.UTF8.GetString(Convert.FromBase64String(authenticationToken));
                    var usernamePasswordArray = decodedAuthenticationToken.Split(':');
                    var userName = usernamePasswordArray[0];
                    var password = usernamePasswordArray[1];
                    var principal = new GenericPrincipal(new GenericIdentity(userName), null);
                    Thread.CurrentPrincipal = principal;
                    using (var userService = new UserService())
                    {
                        if (userService.validateUser(userName, password))
                        {
                            //var principal = new GenericPrincipal(new GenericIdentity(userName), null);
                            Thread.CurrentPrincipal = principal;
                            string requestBody = await request.Content.ReadAsStringAsync();

                            var result = await base.SendAsync(request, cancellationToken);

                            String responseBody = null;
                            if (result.Content != null)
                            {
                                responseBody = await result.Content.ReadAsStringAsync();
                            }
                            var returnedJson = await result.Content.ReadAsStringAsync();

                            string processStatus = StatusEnum.New.ToString();

                            JObject jObj = JObject.Parse(returnedJson);
                            if (jObj.GetValue("Error").ToObject<Boolean>())
                            {
                                processStatus = StatusEnum.Invalid.ToString();
                                errorCode = Convert.ToInt32(jObj.GetValue("ErrorCode"));
                            }

                            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                            ProductFeed feed = json_serializer.Deserialize<ProductFeed>(requestBody);

                            string ProductName = string.Empty;
                            string ProductCode = string.Empty;
                            string Category = string.Empty;
                            string ProductSize = string.Empty;
                            double Price = 0.00;
                            string ProductDescription = string.Empty;
                            string FeedID = string.Empty;
                            String messageId = string.Empty;
                            string jsonString = string.Empty;
                            if (processStatus != "Invalid" && MethodType != "GET")
                            {
                                if (feed != null && feed.FeedID != null && feed.ProductCode != null)
                                {

                                    ProductName = (feed.ProductName != null && feed.ProductName != "") ? feed.ProductName : "";
                                    ProductCode = (feed.ProductCode != null && feed.ProductCode != "") ? feed.ProductCode : "";
                                    Category = (feed.Category != null && feed.Category != "") ? feed.Category : "";
                                    ProductSize = (feed.ProductSize != null && feed.ProductSize != "") ? feed.ProductSize : "";
                                    Price = Convert.ToDouble(feed.Price);
                                    ProductDescription = (feed.ProductDescription != null && feed.ProductDescription != "") ? feed.ProductDescription : "";
                                    FeedID = (feed.FeedID != null && feed.FeedID != "") ? feed.FeedID : "";
                                }

                                
                                using (ProductRequestBL feedObj = new ProductRequestBL())
                                {
                                    feedObj.ProductName = ProductName;
                                    feedObj.ProductCode = ProductCode;
                                    feedObj.ProductDescription = ProductDescription;
                                    feedObj.ProductSize = ProductSize;
                                    feedObj.Category = Category;
                                    feedObj.Price = Price;
                                    feedObj.FeedID = FeedID;
                                    feedObj.MethodType = MethodType;
                                    feedObj.UniqueID = UniqueID;

                                    using (ProductRequestDAL productRequestDAL = new ProductRequestDAL())
                                    {
                                        messageId = productRequestDAL.productLogApiAccess(feedObj);
                                    }

                                }
                                jsonString = JsonConvert.SerializeObject(jObj);
                                if (errorCode == 200)
                                {
                                    string responseStr = result.ToString();
                                    int startIndex = responseStr.IndexOf(':') + 1;
                                    int endIndex = responseStr.IndexOf(',');
                                    int.TryParse(responseStr.Substring(startIndex, endIndex - startIndex), out errorCode);
                                    JObject j = new JObject();
                                    j["UniqueId"] = messageId.ToString();
                                    jsonString = JsonConvert.SerializeObject(j);
                                }
                            }
                            else if (MethodType == "GET")
                            {
                                using (ProductRequestDAL productRequestDAL = new ProductRequestDAL())
                                {
                                    int pageno = Convert.ToInt32(HttpUtility.ParseQueryString(webUri.Query).Get("page"));
                                    int size = Convert.ToInt32(HttpUtility.ParseQueryString(webUri.Query).Get("size"));
                                    string sortby = HttpUtility.ParseQueryString(webUri.Query).Get("sortby");
                                    jsonString = productRequestDAL.productGetProductRequests(UniqueID,pageno,size,sortby);
                                    if (jsonString=="")
                                    {
                                        JObject j = new JObject();
                                        j["Records"] = "[]";
                                        jsonString = JsonConvert.SerializeObject(j);
                                    }
                                }
                                
                            }
                                      
                            
                            HttpResponseMessage httpResponseMessage = CreateJsonResponse(jsonString, errorCode);
                            if (httpResponseMessage == null)
                            {
                                return result;
                            }
                            else
                            {
                                return httpResponseMessage;
                            }
                        }
                        else
                        {
                            throw new UnauthorizedAccessException();
                        }
                    }
                }
                catch (Exception ex)
                {
                    JObject jObj = new JObject();
                    jObj["Error"] = true;               
                    jObj["Message"] = ex.Message.ToString();
                    if(ex.Message.ToString().ToLower().Contains("attempted to perform an unauthorized operation"))
                    {
                        errorCode = 401;
                    }
                    else
                    {
                        errorCode = 500;
                    }
                    jObj["ErrorCode"] = errorCode;              
                    string jsonString = JsonConvert.SerializeObject(jObj);
                    HttpResponseMessage httpResponseMessage = CreateJsonResponse(jsonString, errorCode);
                    return httpResponseMessage;
                }
            }
            else
            {
                throw new UnauthorizedAccessException();
            }

        }

        public static HttpResponseMessage CreateJsonResponse(string json, int statusCode)
        {
            if (statusCode == 401)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.Unauthorized
                };
            }
            else if (statusCode == 404)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.NotFound
                };
            }
            else if (statusCode == 500)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.InternalServerError
                };
            }
            else if (statusCode == 413)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.RequestEntityTooLarge
                };

            }
            else if (statusCode == 400)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.BadRequest
                };

            }
            else if (statusCode == 205)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.ResetContent
                };

            }
            else if (statusCode == 200)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json"),
                    StatusCode = HttpStatusCode.OK
                };

            }
            else if (statusCode < 400)
            {
                return new HttpResponseMessage()
                {
                    Content = new StringContent(json, System.Text.Encoding.UTF8, "application/json")
                };
            }
            else
            {
                return null;
            }
        }
    }
}