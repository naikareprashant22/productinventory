﻿using System.Net.Http.Headers;
using System.Web.Http;
using ProductInventoryAPI.Handler;

namespace ProductInventoryAPI
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            config.MapHttpAttributeRoutes();// Web API routes
            config.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("application/json"));  // For Request and Response Content Type Only JSON
            config.MessageHandlers.Add(new ProductLogRequestResponseHandler());
        }
    }
}
