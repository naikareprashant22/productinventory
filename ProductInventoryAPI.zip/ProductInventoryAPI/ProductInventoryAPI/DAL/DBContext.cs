﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace ProductInventoryAPI.DAL
{
    public class DBContext : IDisposable
    {
        public SqlConnection connection = null;
        public SqlCommand cmd = null;
        public SqlDataAdapter ada = null;

        public void Initialize()
        {
            try
            {
                connection = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString());
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                ada = new SqlDataAdapter();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public void Close()
        {
            try
            {
                connection.Close();
                cmd.Dispose();
                ada.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }
        public void Dispose()
        {
            GC.Collect();
        }
    }
   
}