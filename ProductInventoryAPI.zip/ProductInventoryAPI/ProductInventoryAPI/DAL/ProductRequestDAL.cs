﻿using System;
using ProductInventoryAPI.Models;
using System.Data;

namespace ProductInventoryAPI.DAL
{
    public class ProductRequestDAL :  DBContext
    {
        public string productLogApiAccess(ProductRequestBL obj)
        {
            string result = string.Empty;
            if(obj.MethodType == "POST")
            {
                obj.UniqueID = Guid.NewGuid().ToString();
            }
            result = obj.UniqueID;
            this.Initialize();
            try
            {
                cmd.CommandText = "sp_crud_operation_api";
                cmd.Parameters.Add("@paramProductName", SqlDbType.VarChar).Value = obj.ProductName;
                cmd.Parameters.Add("@paramProductCode", SqlDbType.VarChar).Value = obj.ProductCode;
                cmd.Parameters.Add("@paramCategory", SqlDbType.VarChar).Value = obj.Category;
                cmd.Parameters.Add("@paramProductSize", SqlDbType.VarChar).Value = obj.ProductSize;
                cmd.Parameters.Add("@paramPrice", SqlDbType.Float).Value = obj.Price;
                cmd.Parameters.Add("@paramProductDescription", SqlDbType.VarChar).Value = obj.ProductDescription;
                cmd.Parameters.Add("@paramFeedID", SqlDbType.VarChar).Value = obj.FeedID;
                cmd.Parameters.Add("@paramUniqueID", SqlDbType.VarChar).Value = obj.UniqueID;
                cmd.Parameters.Add("@paramOperationType", SqlDbType.VarChar).Value = obj.MethodType;

                connection.Open();
                cmd.Connection = connection;
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.Close();
            }
            return result;
        }

        public string productGetProductRequests(string uniqueid, int pageno ,int size,string sortby)
        {
            string result = string.Empty;
            DataTable dt = new DataTable();
            this.Initialize();
            try
            {
                cmd.CommandText = "sp_get_productsearch_api";               
                cmd.Parameters.Add("@paramUniqueID", SqlDbType.VarChar).Value = uniqueid;
                cmd.Parameters.Add("@paramPage", SqlDbType.Int).Value = pageno;
                cmd.Parameters.Add("@paramSize", SqlDbType.Int).Value = size;
                cmd.Parameters.Add("@paramSortBy", SqlDbType.VarChar).Value = sortby;
              
                connection.Open();
                cmd.Connection = connection;
                using (var reader = cmd.ExecuteReader())
                {
                    dt.Load(reader);
                }
                if(dt.Rows.Count > 0)
                {
                    result = dt.Rows[0][0].ToString();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.Close();
            }
            return result;
        }

    }
}