﻿using System;
using System.Data;
using ProductInventoryAPI.DAL;

namespace ProductInventoryAPI.Models
{
    public class UserService : IDisposable
    {
        public bool validateUser(String userName, String password)
        {
            try
            {                
                    bool flag = false;

                    var AuthInfo = System.Configuration.ConfigurationManager.AppSettings["AuthInfo"].ToString();
                    if (AuthInfo == userName + ":"+ password)
                    {
                        flag = true;
                    }
                    else
                    {
                        flag = false;
                    }
                return flag;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }     
        public void Dispose()
        {
            GC.Collect();
        }
    }
}