﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductInventoryAPI.Models
{
    [Serializable]
    public class MessageResponse
    {
        public bool Error;      

        public String Message;

        public int ErrorCode;

   

        public MessageResponse()
        {

        }

        private MessageResponse(int messageId, String message)
        {
            this.Error = false;        
            this.Message = message;
        }

        private MessageResponse(String message, int errorCode)
        {
            this.Error = true;
            this.Message = message;
            this.ErrorCode = errorCode;
        }

        private MessageResponse(int messageId, String message, int errorCode, String errorDetails)
        {
            this.Error = true;
            this.Message = message;
            this.ErrorCode = errorCode;         
        }

        public static MessageResponse getSuccessMessageResponse(int messageId, String message)
        {
            return new MessageResponse(messageId, message);
        }

        public static MessageResponse getErrorMessageResponse(String message, int errorCode)
        {
            return new MessageResponse(message, errorCode);
        }

        public static MessageResponse getErrorMessageResponseWithExtraDetails
            (int messageId, String message, int errorCode, String errorDetails)
        {
            return new MessageResponse(messageId, message, errorCode, errorDetails);
        }
    }
}