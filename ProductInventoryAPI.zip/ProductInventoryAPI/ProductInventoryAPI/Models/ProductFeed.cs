﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProductInventoryAPI.Models
{
    public class ProductFeed
    {
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public string Category { get; set; }
        public string ProductSize { get; set; }
        public double Price { get; set; }
        public string ProductDescription { get; set; }
        public string FeedID { get; set; }
        public string UniqueID { get; set; }


    }
}