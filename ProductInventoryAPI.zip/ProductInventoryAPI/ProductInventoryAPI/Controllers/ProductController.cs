﻿using ProductInventoryAPI.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;


namespace ProductInventoryAPI.Controllers
{
    public class ProductController : ApiController
    {
        [HttpPost]
        [Route("api/product-request")]
        public async Task<MessageResponse> ProductRequestPost(ProductFeed productFeed)
        {

            
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);          
            await Task.Delay(delayFeedRequest);

            if (productFeed == null)
                return MessageResponse.getErrorMessageResponse("Invalid JSON Response or Parser Error", 400);
            else if (productFeed.FeedID == null || productFeed.FeedID.Trim().Length == 0)
                return MessageResponse.getErrorMessageResponse("Invalid Payload, FeedID is required.", 400);
            else if (productFeed.ProductCode == null || productFeed.ProductCode.Trim().Length == 0)
                return MessageResponse.getErrorMessageResponse("Invalid Payload, Product code is required.", 400);            
            try
            {
                return MessageResponse.getSuccessMessageResponse(-1, "Feed Id - " + productFeed.FeedID + " inserted successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPut]
        [Route("api/product-request/{uniqueid}")]
        public async Task<MessageResponse> ProductRequestPut(ProductFeed productFeed)
        {

           
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);
            await Task.Delay(delayFeedRequest);

            if (productFeed == null)
                return MessageResponse.getErrorMessageResponse("Invalid JSON Response or Parser Error", 400);
            else if (productFeed.FeedID == null || productFeed.FeedID.Trim().Length == 0)
                return MessageResponse.getErrorMessageResponse("Invalid Payload, FeedID is required.", 400);
            else if (productFeed.ProductCode == null || productFeed.ProductCode.Trim().Length == 0)
                return MessageResponse.getErrorMessageResponse("Invalid Payload, Product code is required.", 400);
            
            try
            {
                return MessageResponse.getSuccessMessageResponse(-1, "Feed Id - " + productFeed.FeedID + " inserted successfully");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpDelete]
        [Route("api/product-request/{uniqueid}")]
        public async Task<MessageResponse> ProductRequestDelete(ProductFeed productFeed)
        {

           
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);
            await Task.Delay(delayFeedRequest);
            try
            {
                return MessageResponse.getSuccessMessageResponse(-1, "200");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("api/product-search")]
        public async Task<MessageResponse> ProductRequesGetAll(ProductFeed productFeed)
        {

            
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);
            await Task.Delay(delayFeedRequest);
            try
            {
                return MessageResponse.getSuccessMessageResponse(-1, "200");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        [Route("api/product-search/{uniqueid}")]
        public async Task<MessageResponse> ProductRequestSearch(ProductFeed productFeed)
        {

           
            int delayFeedRequest = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["DelayForFeedRequest"]);
            await Task.Delay(delayFeedRequest);
            try
            {
                return MessageResponse.getSuccessMessageResponse(-1, "200");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}